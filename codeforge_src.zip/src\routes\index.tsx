import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  Sparkles, ArrowRight, Code2, Cpu, Layers, Rocket, BookOpen, Brain,
  FileText, MessageSquareCode, GraduationCap, Wand2, Github, Linkedin,
  Star, Zap, Shield,
} from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

const SITE_URL = "https://codeforgedev.vercel.app";
const OG_IMAGE = "https://storage.googleapis.com/gpt-engineer-file-uploads/attachments/og-images/cb2daafa-ef7b-443c-91ff-56bf8bc32259";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CodeForge — Portfolio, Blog & AI Tools for Developers" },
      { name: "description", content: "Premium portfolio, technical blog and AI productivity tools hub for developers, students and creators. Built with React, TypeScript and TanStack." },
      { name: "keywords", content: "developer portfolio, technical blog, AI tools, resume builder, code explainer, React, TypeScript, TanStack" },
      { property: "og:title", content: "CodeForge — Portfolio, Blog & AI Tools for Developers" },
      { property: "og:description", content: "Portfolio · Blog · AI productivity tools, all in one place." },
      { property: "og:url", content: SITE_URL + "/" },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:image", content: OG_IMAGE },
      { name: "twitter:title", content: "CodeForge — Portfolio, Blog & AI Tools" },
      { name: "twitter:description", content: "Portfolio · Blog · AI productivity tools, all in one place." },
    ],
    links: [{ rel: "canonical", href: SITE_URL + "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Person",
          name: "CodeForge",
          url: SITE_URL,
          jobTitle: "Software Developer",
          sameAs: [SITE_URL],
        }),
      },
    ],
  }),
  component: Home,
});


const AI_TOOLS = [
  { slug: "resume-builder", title: "AI Resume Builder", desc: "Craft ATS-ready resumes from your raw experience.", icon: FileText, accent: "from-violet to-fuchsia-500" },
  { slug: "study-notes", title: "Study Notes Generator", desc: "Turn any topic into structured notes & summaries.", icon: BookOpen, accent: "from-sky-500 to-electric" },
  { slug: "quiz-generator", title: "Quiz Generator", desc: "10-question MCQ quizzes for any subject in seconds.", icon: GraduationCap, accent: "from-emerald-500 to-electric" },
  { slug: "code-explainer", title: "Code Explainer", desc: "Decode snippets line-by-line with senior-dev clarity.", icon: MessageSquareCode, accent: "from-violet to-pink-500" },
  { slug: "interview-questions", title: "Interview Q Generator", desc: "Targeted interview prep questions for any role.", icon: Brain, accent: "from-amber-500 to-rose-500" },
  { slug: "text-improver", title: "Text Improver", desc: "Refine tone, clarity and grammar without losing voice.", icon: Wand2, accent: "from-electric to-violet" },
];

function Home() {
  const projects = useQuery({
    queryKey: ["projects", "featured"],
    queryFn: async () => {
      const { data, error } = await supabase.from("projects").select("*").eq("featured", true).order("order_index").limit(3);
      if (error) throw error;
      return data;
    },
  });

  const posts = useQuery({
    queryKey: ["posts", "featured"],
    queryFn: async () => {
      const { data, error } = await supabase.from("posts").select("id,slug,title,excerpt,cover_image,category,reading_time,created_at").eq("published", true).order("created_at", { ascending: false }).limit(3);
      if (error) throw error;
      return data ?? [];
    },
  });

  return (
    <SiteLayout>
      {/* HERO */}
      <section className="relative overflow-hidden pt-20 pb-32">
        <div className="absolute inset-0 grid-bg" aria-hidden />
        <div className="relative mx-auto max-w-7xl px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="mx-auto max-w-4xl text-center">
          
            <div className="mx-auto inline-flex items-center gap-2 rounded-full glass px-3 py-1.5 text-xs font-medium">
              <Sparkles className="h-3.5 w-3.5 text-violet" />
              <span className="text-muted-foreground">Welcome to the Future World</span>
            </div>
            <h1 className="mt-6 font-display text-5xl font-bold leading-[1.05] tracking-tight md:text-7xl">
              Forge ideas into <span className="gradient-text">reality</span>.
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-balance text-lg text-muted-foreground">
              CodeForge is a personal portfolio, technical blog, and AI tools hub — engineered for developers, students and creators who ship.
            </p>
            <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
              <Button asChild size="lg" className="rounded-xl bg-gradient-to-r from-violet to-electric text-white shadow-lg shadow-violet/30 hover:opacity-95">
                <Link to="/projects">Explore Projects <ArrowRight className="ml-1.5 h-4 w-4" /></Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="rounded-xl border-border/60 bg-white/5 backdrop-blur hover:bg-white/10">
                <Link to="/ai-tools">Try AI Tools</Link>
              </Button>
            </div>
            <div className="mx-auto mt-10 flex max-w-md items-center justify-center gap-6 text-xs text-muted-foreground">
              <div className="flex items-center gap-1.5"><Shield className="h-3.5 w-3.5 text-electric" />Secure auth</div>
              <div className="flex items-center gap-1.5"><Zap className="h-3.5 w-3.5 text-electric" />Realtime DB</div>
              <div className="flex items-center gap-1.5"><Cpu className="h-3.5 w-3.5 text-electric" />AI powered</div>
            </div>
          </motion.div>

          {/* Stat strip */}
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="glass-strong mx-auto mt-20 grid max-w-4xl grid-cols-2 gap-px overflow-hidden rounded-3xl md:grid-cols-4">
            {[
              { v: "4+", l: "Projects Built" },
              { v: "15K+", l: "Lines of Code" },
              { v: "8", l: "AI tools" },
              { v: "24/7", l: "Always learning" },
            ].map((s) => (
              <div key={s.l} className="bg-card/80 p-5 text-center">
                <div className="font-display text-2xl font-bold gradient-text">{s.v}</div>
                <div className="mt-1 text-xs text-muted-foreground">{s.l}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* FEATURED PROJECTS */}
      <section className="mx-auto max-w-7xl px-4 py-20">
        <SectionHeading eyebrow="Selected work" title="Featured projects" cta={{ to: "/projects", label: "All projects" }} />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {(projects.data ?? []).map((p, i) => (
            <motion.div key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }} className="group glass relative flex h-full flex-col rounded-2xl p-6 transition hover:-translate-y-1">
              <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-violet to-transparent opacity-40" />
              <div className="mb-4 inline-flex w-fit items-center gap-1.5 rounded-full bg-white/5 px-2.5 py-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                {p.category ?? "Project"}
              </div>
              <h3 className="font-display text-xl font-semibold">{p.title}</h3>
              <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">{p.description}</p>
              <div className="mt-4 flex flex-wrap gap-1.5">
                {p.tags.slice(0, 3).map((t) => (
                  <span key={t} className="rounded-md border border-border/60 px-2 py-0.5 text-[10px] font-mono text-muted-foreground">{t}</span>
                ))}
              </div>
              <Link to="/projects" className="mt-5 inline-flex items-center gap-1 text-sm font-medium text-electric group-hover:gap-2">
                View case study <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
              </Link>
            </motion.div>
          ))}
          {projects.isLoading && Array.from({ length: 3 }).map((_, i) => <div key={i} className="glass h-56 rounded-2xl shimmer" />)}
        </div>
      </section>

      {/* AI TOOLS SHOWCASE */}
      <section className="mx-auto max-w-7xl px-4 py-20">
        <SectionHeading eyebrow="AI productivity" title="A toolbelt powered by AI" cta={{ to: "/ai-tools", label: "Open AI hub" }} />
        <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {AI_TOOLS.map((t, i) => (
            <motion.div key={t.slug} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}>
              <Link to="/ai-tools/$tool" params={{ tool: t.slug }} className="group glass relative block h-full overflow-hidden rounded-2xl p-6 transition hover:-translate-y-1">
                <div className={`mb-4 grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br ${t.accent} text-white`}>
                  <t.icon className="h-5 w-5" />
                </div>
                <h3 className="font-display text-lg font-semibold">{t.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{t.desc}</p>
                <div className="mt-4 inline-flex items-center gap-1 text-xs font-medium text-electric">Launch tool <ArrowRight className="h-3 w-3" /></div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* FEATURED BLOG */}
      <section className="mx-auto max-w-7xl px-4 py-20">
        <SectionHeading eyebrow="Writing" title="From the blog" cta={{ to: "/blog", label: "Read all posts" }} />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {posts.data && posts.data.length > 0 ? (
            posts.data.map((p, i) => (
              <motion.div key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }} className="glass rounded-2xl p-6">
                <div className="text-[10px] uppercase tracking-wider text-electric">{p.category ?? "Article"}</div>
                <h3 className="mt-2 font-display text-lg font-semibold">
                  <Link to="/blog/$slug" params={{ slug: p.slug }} className="hover:gradient-text">{p.title}</Link>
                </h3>
                <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">{p.excerpt}</p>
                <div className="mt-4 text-xs text-muted-foreground">{p.reading_time} min read</div>
              </motion.div>
            ))
          ) : (
            <div className="glass md:col-span-3 rounded-2xl p-10 text-center text-sm text-muted-foreground">
              No posts yet. <Link to="/auth" className="text-electric">Sign in</Link> and publish the first article.
            </div>
          )}
        </div>
      </section>

      {/* SKILLS */}
      <section className="mx-auto max-w-7xl px-4 py-20">
        <SectionHeading eyebrow="Stack" title="The tech I forge with" />
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {[
            { title: "Frontend", icon: Layers, items: ["React", "TypeScript", "Tailwind", "Framer Motion", "TanStack"] },
            { title: "Backend", icon: Code2, items: ["Node.js", "PostgreSQL", "Supabase", "Edge Functions", "REST/GraphQL"] },
            { title: "AI / ML", icon: Cpu, items: ["OpenAI", "Gemini", "LangChain", "Vector DBs", "Prompt Engineering"] },
          ].map((g) => (
            <div key={g.title} className="glass gradient-border rounded-2xl p-6">
              <div className="flex items-center gap-2">
                <g.icon className="h-4 w-4 text-electric" />
                <h3 className="font-display text-base font-semibold">{g.title}</h3>
              </div>
              <ul className="mt-4 flex flex-wrap gap-2">
                {g.items.map((it) => (
                  <li key={it} className="rounded-md bg-white/5 px-2.5 py-1 text-xs font-mono">{it === "React" ? `This website is built with React\n` : it}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="mx-auto max-w-7xl px-4 py-20">
        <SectionHeading eyebrow="What people say" title="Trusted by builders" />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {[
            { name: "Maya R.", role: "Frontend Engineer", quote: "CodeForge's AI tools shaved hours off my weekly study & writing routine. The Quiz Generator is unreal." },
            { name: "Daniel K.", role: "CS Student", quote: "Used the Study Notes & Interview Q generators to land my first internship. Beautifully designed too." },
            { name: "Priya S.", role: "Indie Dev", quote: "Honestly the cleanest personal portfolio + blog setup I've seen. Inspired me to ship mine." },
          ].map((t, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }} className="glass rounded-2xl p-6">
              <div className="flex gap-0.5">{Array.from({ length: 5 }).map((_, n) => <Star key={n} className="h-4 w-4 fill-electric text-electric" />)}</div>
              <p className="mt-4 text-sm leading-relaxed">"{t.quote}"</p>
              <div className="mt-5 text-xs"><span className="font-semibold">{t.name}</span> · <span className="text-muted-foreground">{t.role}</span></div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 py-20">
        <div className="glass-strong gradient-border relative overflow-hidden rounded-3xl p-10 text-center md:p-16">
          <div className="absolute -top-32 left-1/2 h-72 w-[40rem] -translate-x-1/2 rounded-full bg-violet/30 blur-[120px]" aria-hidden />
          <div className="relative">
            <Rocket className="mx-auto mb-4 h-8 w-8 text-electric" />
            <h2 className="font-display text-3xl font-bold md:text-5xl">Ready to forge something new?</h2>
            <p className="mx-auto mt-3 max-w-xl text-muted-foreground">Sign in to create posts, save articles, and unlock the full AI hub.</p>
            <div className="mt-7 flex flex-wrap justify-center gap-3">
              <Button asChild size="lg" className="rounded-xl bg-gradient-to-r from-violet to-electric text-white">
                <Link to="/auth">Get started — it's free</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="rounded-xl">
                <a href="https://github.com/placeholder" target="_blank" rel="noreferrer"><Github className="mr-1.5 h-4 w-4" />GitHub</a>
              </Button>
              <Button asChild size="lg" variant="outline" className="rounded-xl">
                <a href="https://linkedin.com/in/placeholder" target="_blank" rel="noreferrer"><Linkedin className="mr-1.5 h-4 w-4" />LinkedIn</a>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}

function SectionHeading({ eyebrow, title, cta }: { eyebrow: string; title: string; cta?: { to: string; label: string } }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div>
        <div className="text-xs uppercase tracking-[0.18em] text-electric">{eyebrow}</div>
        <h2 className="mt-2 font-display text-3xl font-bold md:text-4xl">{title}</h2>
      </div>
      {cta && (
        <Link to={cta.to} className="group inline-flex items-center gap-1 rounded-lg border border-border/60 bg-white/5 px-3 py-1.5 text-sm hover:border-violet/60">
          {cta.label} <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
        </Link>
      )}
    </div>
  );
}
